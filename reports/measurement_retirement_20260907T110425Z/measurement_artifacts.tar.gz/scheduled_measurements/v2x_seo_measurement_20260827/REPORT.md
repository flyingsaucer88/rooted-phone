# V2X — BLOCKED

| Field | Value |
| --- | --- |
| run_id | `v2x_seo_measurement_20260827` |
| status | **BLOCKED** |
| verdict | BLOCKED — SOURCE PROMPT NOT INSTALLED |
| intended (IST) | 2026-08-27T01:00:00+0530 |
| actual (IST) | 2026-09-07T15:08:50+0530 |
| device | Moto G (4) ZY22382BFL |
| timezone | Asia/Kolkata (offset +0530) |
| source prompt | `v2x_measurement_gate.md` |
| prompt sha256 | `absent` |
| attempts today | 6 |

## Blocker

Source prompt not installed at `/data/data/com.termux/files/home/measurement_queue/prompts/v2x_measurement_gate.md`. The immutable copy was never supplied, so there is nothing authoritative to execute.

## Authenticated-source preflight

```
gsc=UNAVAILABLE (Google service-account credential is MISSING)
ga4=UNAVAILABLE (Google service-account credential is MISSING)
bing=UNAVAILABLE_OPTIONAL (Bing Webmaster API key is MISSING) — run continues, metric reported unavailable
serp=UNAVAILABLE_OPTIONAL (no compliant standalone SERP source) — GSC is the ranking source of truth
ai_overview=UNAVAILABLE_OPTIONAL (GOOGLE_AI_OVERVIEW = NOT AVAILABLE IN STANDALONE API MODE)
claude=UNAVAILABLE (Anthropic API key is MISSING)
```

## Mutation proof

production mutations = 0
GA4 mutations = 0
GSC mutations = 0
Bing mutations = 0
outreach actions = 0
indexing requests = 0

No measurement data was collected, inferred or fabricated.
