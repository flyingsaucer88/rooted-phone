# AmbiSecure — BLOCKED

| Field | Value |
| --- | --- |
| run_id | `ambisecure_gsc_7day_20260829` |
| status | **BLOCKED** |
| verdict | BLOCKED — SOURCE PROMPT NOT INSTALLED |
| intended (IST) | 2026-08-29T01:00:00+0530 |
| actual (IST) | 2026-09-07T15:08:54+0530 |
| device | Moto G (4) ZY22382BFL |
| timezone | Asia/Kolkata (offset +0530) |
| source prompt | `ambisecure_gsc_7day.md` |
| prompt sha256 | `absent` |
| attempts today | 6 |

## Blocker

Source prompt not installed at `/data/data/com.termux/files/home/measurement_queue/prompts/ambisecure_gsc_7day.md`. The immutable copy was never supplied, so there is nothing authoritative to execute.

## Authenticated-source preflight

```
gsc=UNAVAILABLE (Google service-account credential is MISSING)
claude=UNAVAILABLE (Anthropic API key is MISSING)
```

## Mutation proof

production mutations = 0
GA4 mutations = 0
GSC mutations = 0
Bing mutations = 0
outreach actions = 0
indexing requests = 0

No measurement data was collected, inferred or fabricated.
