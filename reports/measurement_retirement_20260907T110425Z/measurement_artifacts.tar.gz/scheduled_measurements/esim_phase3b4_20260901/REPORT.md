# eSIM — BLOCKED

| Field | Value |
| --- | --- |
| run_id | `esim_phase3b4_20260901` |
| status | **BLOCKED** |
| verdict | BLOCKED — AUTHENTICATED DATA SOURCE UNAVAILABLE |
| intended (IST) | 2026-09-01T01:00:00+0530 |
| actual (IST) | 2026-09-07T15:08:58+0530 |
| device | Moto G (4) ZY22382BFL |
| timezone | Asia/Kolkata (offset +0530) |
| source prompt | `esim_phase3b4.md` |
| prompt sha256 | `59fe806c67447cdd1aea5a9cbd4edafb40891330a4f19aed77e429a3ae6d0189` |
| attempts today | 6 |

## Blocker

One or more required sources (gsc,ga4,linkedin) cannot be reached unattended from this device.

## Authenticated-source preflight

```
gsc=UNAVAILABLE (Google service-account credential is MISSING)
ga4=UNAVAILABLE (Google service-account credential is MISSING)
linkedin=UNAVAILABLE_OPTIONAL (LinkedIn member-analytics token is MISSING) — run continues, metric reported unavailable
claude=UNAVAILABLE (Anthropic API key is MISSING)
```

## Mutation proof

production mutations = 0
GA4 mutations = 0
GSC mutations = 0
Bing mutations = 0
outreach actions = 0
indexing requests = 0

No measurement data was collected, inferred or fabricated.
