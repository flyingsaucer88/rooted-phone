# Scheduled measurement runs — index

Generated 2026-09-07 16:30:05 +0530 (Asia/Kolkata). Index only; evidence lives in each run directory.

| Run | Intended Time | Actual Time | Status | Verdict | Evidence Directory |
| --- | --- | --- | --- | --- | --- |
| V2X | 2026-08-27T01:00:00+0530 | 2026-09-07T15:08:51+0530 | blocked | BLOCKED — SOURCE PROMPT NOT INSTALLED | /data/data/com.termux/files/home/scheduled_measurements/v2x_seo_measurement_20260827 |
| AmbiSecure | 2026-08-29T01:00:00+0530 | 2026-09-07T15:08:55+0530 | blocked | BLOCKED — SOURCE PROMPT NOT INSTALLED | /data/data/com.termux/files/home/scheduled_measurements/ambisecure_gsc_7day_20260829 |
| Ambimat | 2026-08-29T01:00:00+0530 | — | scheduled | — | — |
| eSIM | 2026-09-01T01:00:00+0530 | 2026-09-07T15:08:59+0530 | blocked | BLOCKED — AUTHENTICATED DATA SOURCE UNAVAILABLE | /data/data/com.termux/files/home/scheduled_measurements/esim_phase3b4_20260901 |

Blackout dates (no measurement runs): `2026-08-28`
